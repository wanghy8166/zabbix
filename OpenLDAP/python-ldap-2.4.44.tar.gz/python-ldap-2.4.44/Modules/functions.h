/* See https://www.python-ldap.org/ for details.
 * $Id: functions.h,v 1.5 2017/08/15 16:21:59 stroeder Exp $ */

#ifndef __h_functions_
#define __h_functions_

/* $Id: functions.h,v 1.5 2017/08/15 16:21:59 stroeder Exp $ */

#include "common.h"
extern void LDAPinit_functions( PyObject* );

#endif /* __h_functions_ */
