/* See https://www.python-ldap.org/ for details.
 * $Id: schema.h,v 1.6 2017/08/15 16:21:59 stroeder Exp $ */

#ifndef __h_schema_
#define __h_schema_



#include "common.h"
extern void LDAPinit_schema( PyObject* );


#endif /* __h_schema_ */

