/* Set release version
 * See https://www.python-ldap.org/ for details.
 * $Id: version.h,v 1.5 2017/08/15 16:21:59 stroeder Exp $ */

#ifndef __h_version_
#define __h_version_


#include "common.h"
extern void LDAPinit_version( PyObject* d );

#endif /* __h_version_ */
